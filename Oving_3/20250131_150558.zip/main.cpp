#include "std_lib_facilities.h"
#include "cannonball.h"

int main()
{
	if(true){
		int testpos1,testpos2;
		testpos1, testpos2 = posX(0,50,5), posY(0,0.475,5);
		cout << testpos1 << "og" << testpos2;
	}
	else{
		playTargetPractice();
	}
	return 0;
}