#pragma once
#include "utilities.h"
#include "std_lib_facilities.h"

void testCallByValue();
void testCallByReference();
void testString();
void testCallByReference();