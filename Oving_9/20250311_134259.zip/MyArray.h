#pragma once
#include <iostream>
#include <exception>

// BEGIN 5a
template<typename Type, int Size>
// END 5a
class MyArray
{
    private:
        // BEGIN 5b
        Type elements[Size];
        // END 5b
    public:
        // BEGIN 5c

        // END 5c
};

// BEGIN 5d

// END 5d