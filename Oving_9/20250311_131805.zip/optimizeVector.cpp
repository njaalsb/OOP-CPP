#include "Stopwatch.h"
#include "optimizeVector.h"
#include <vector>
#include <iostream>


// BEGIN 2a
void testVector(){
    std::vector<int> vec;
    std::cout << "Størrelse: " << vec.size() << std::endl;
    std::cout << "Kapasitet: " << vec.capacity() << std::endl;
    vec.resize(20);
    
    for (int i = 0; i < 19; i++)
    {
        vec[i] = i;
        std::cout << "Størrelse: " << vec.size() << std::endl;
        std::cout << "Kapasitet: " << vec.capacity() << std::endl;
    }
}
// END 2a


void optimizeVector(){
    // BEGIN 2d
    Stopwatch s;
    uint16_t iterasjoner = 1000000;
    std::vector<int> vec_1;

    s.start();
    for (int i = 0; i < iterasjoner; i++)
    {
        vec_1.push_back(1);
    }
    double tid = s.stop()/static_cast<double>(iterasjoner);

    std::cout << "Oppgave 2d: " << tid << std::endl;
    // END 2d

    // BEGIN 2e
    Stopwatch t;
    std::vector<int> vec_2;

    t.start();
    vec_2.reserve(iterasjoner);
    vec_2.resize(iterasjoner);
    for (int i = 0; i < iterasjoner; i++)
    {
        vec_2[i] = 1;
    }
    double tid_2 = t.stop()/static_cast<double>(iterasjoner);
    std::cout << "Oppgave 2e: " << tid_2 << std::endl;
    // END 2e   
}