#pragma once

void testVector();
void optimizeVector();